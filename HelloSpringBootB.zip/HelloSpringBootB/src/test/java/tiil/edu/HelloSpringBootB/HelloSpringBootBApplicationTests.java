package tiil.edu.HelloSpringBootB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpringBootBApplicationTests {

	@Test
	void contextLoads() {
	}

}
