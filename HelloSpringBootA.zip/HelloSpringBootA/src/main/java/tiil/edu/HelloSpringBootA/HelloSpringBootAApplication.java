package tiil.edu.HelloSpringBootA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloSpringBootAApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloSpringBootAApplication.class, args);
	}

}
