package tiil.edu.HelloSpringBootB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloSpringBootBApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloSpringBootBApplication.class, args);
	}

}
